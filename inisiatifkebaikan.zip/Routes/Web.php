<?php

use App\Config\Router;

Router::get('/', 'HomeController@index');
