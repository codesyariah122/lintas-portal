<?php
namespace Core\Commons;

class RouteListCore {
	protected static function listRoutes()
	{
		return ConstantsCommons::$routeLists;
	}
}