<!-- Carousel -->
<div id="indicators-carousel" class="relative w-full -mt-8" data-carousel="static">
    <!-- Carousel wrapper -->
    <div class="relative h-56 overflow-hidden rounded-lg md:h-96">
        <!-- Item 1 -->
        <div class="hidden duration-700 ease-in-out mt-4" data-carousel-item>
            <img src="https://amalsholeh-s3.imgix.net/user-media/y8BaIz1FoXV846FfmAfSwJcxWGJBfbPxEakN3wop.png?&w=1000?w=534&fit=crop&auto=format,compress" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
        <!-- Item 2 -->
        <div class="hidden duration-700 ease-in-out mt-4" data-carousel-item>
            <img src="https://amalsholeh-s3.imgix.net/user-media/1YVcdQMxzIYaB5JRSDY8TQ84zuJOspz2YQbFCmHy.png?&w=1000?w=534&fit=crop&auto=format,compress" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
        </div>
    </div>
    <!-- Slider indicators -->
    <div id="carousel-indicators" class="absolute z-30 flex -translate-x-1/2 bottom-5 left-1/2 space-x-3 rtl:space-x-reverse">
        <button type="button" class="w-3 h-3 rounded-full active" aria-current="true" aria-label="Slide 1" data-carousel-slide-to="0" onclick="activeSlide(0)"></button>
        <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 2" data-carousel-slide-to="1" onclick="activeSlide(1)"></button>
    </div>
</div>
<!-- End Carousel -->