<?php foreach ($contents as $content) : ?>
    <?php require_once "Resources/views/" . $content . ".core.php" ?>
<?php endforeach; ?>