<!DOCTYPE html>
<html>
<head>
    <title><?=$title?></title>
</head>
<body>
    <h1 style="color: red; text-align: center; padding-top:25px;">
        <?php echo $message; ?>
    </h1>
</body>
</html>
