<?php

namespace App\Controllers;

use Core\ControllerCore;

class HomeController extends ControllerCore
{

	public function index()
	{
		$layout = 'Layouts/DefaultLayout';
		$view = 'home';
		$dataResponse = [
			"title" => ucfirst("inisiatif kebaikan"),
			'message' => 'Lintas Portal Website !!',
			'contents' => ['Home/Carousel', 'Home/Articles']
		];
		// $this->jsonResponse($dataResponse);
		$this->render($view, $layout, $dataResponse);
	}

	public function all()
	{
	}

	public function create()
	{
	}

	public function update()
	{
	}

	public function delete()
	{
	}
}
