<?php
namespace App\Data;

class WebSource {
	public static function renderContents($page){
	}
}